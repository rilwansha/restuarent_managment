
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 4.5.1
    </div>
    <strong>Copyright &copy; 2012 - <?php echo date('Y'); ?> SandoSoft.</strong> All rights
    reserved.
  </footer>

  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

</body>
</html>
